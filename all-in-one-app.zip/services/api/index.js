require('dotenv').config();
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const upload = multer({ dest: 'uploads/' });
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.API_PORT || 4000;

// Simple health
app.get('/health', (req, res) => res.json({ ok: true }));

// PDF -> DOCX upload stub
app.post('/convert/pdf-to-docx', upload.single('pdf'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  // For production: send file to CloudConvert or move to worker volume for LibreOffice conversion.
  // Here we return a stub response with the uploaded filename.
  res.json({
    ok: true,
    message: 'File received on API (stub). Implement conversion with CloudConvert or worker.',
    filename: req.file.filename,
    originalname: req.file.originalname
  });
});

// Static downloads (for demo only)
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.listen(PORT, () => console.log('API running on port', PORT));
