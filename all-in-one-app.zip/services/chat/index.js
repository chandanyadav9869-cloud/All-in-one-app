const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

io.on('connection', socket => {
  console.log('socket connected', socket.id);
  socket.on('join', room => {
    socket.join(room);
    console.log(socket.id, 'joined', room);
  });
  socket.on('msg', data => {
    // data: { room, author, text }
    if (data && data.room) {
      io.to(data.room).emit('msg', { author: data.author, text: data.text, ts: Date.now() });
    }
  });
});

const PORT = process.env.CHAT_PORT || 5000;
server.listen(PORT, ()=> console.log('Chat server running on', PORT));
