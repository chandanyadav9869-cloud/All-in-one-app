import Link from 'next/link';
export default function Home(){
  return (
    <div className="container">
      <h1>All-in-One App (Scaffold)</h1>
      <p>This is a minimal frontend scaffold. Use the links below to test parts.</p>
      <div style={{display:'flex', gap:12, marginTop:16}}>
        <Link href="/tools/pdf"><a className="btn">PDF → Word</a></Link>
        <Link href="/tools/excel"><a className="btn">Excel</a></Link>
        <Link href="/chat"><a className="btn">Chat</a></Link>
      </div>
    </div>
  )
}
