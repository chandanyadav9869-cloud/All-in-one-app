import { useEffect, useRef, useState } from 'react';
import io from 'socket.io-client';
let socket;
export default function ChatPage(){
  const [room, setRoom] = useState('room1');
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const mounted = useRef(false);
  useEffect(()=> {
    if (mounted.current) return;
    socket = io((process.env.NEXT_PUBLIC_CHAT_URL||'http://localhost:5000'));
    socket.on('connect', ()=> console.log('connected'));
    socket.on('msg', m => setMsgs(prev=>[...prev, m]));
    mounted.current = true;
    return ()=> socket?.disconnect();
  }, []);
  const join = ()=> socket.emit('join', room);
  const send = ()=> {
    socket.emit('msg', { room, author: 'You', text });
    setText('');
  }
  return (
    <div className="container">
      <h2>Chat (Socket.IO demo)</h2>
      <div className="card">
        <div>
          <label>Room: <input value={room} onChange={e=>setRoom(e.target.value)} /></label>
          <button onClick={join} className="btn" style={{marginLeft:8}}>Join</button>
        </div>
        <div style={{marginTop:12, maxHeight:240, overflow:'auto', border:'1px solid #eee', padding:8}}>
          {msgs.map((m,i)=>(<div key={i}><b>{m.author}</b>: {m.text}</div>))}
        </div>
        <div style={{marginTop:8}}>
          <input value={text} onChange={e=>setText(e.target.value)} />
          <button onClick={send} className="btn" style={{marginLeft:8}}>Send</button>
        </div>
      </div>
    </div>
  )
}
