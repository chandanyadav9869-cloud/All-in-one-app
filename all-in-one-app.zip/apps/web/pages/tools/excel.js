import { useState } from 'react';
import * as XLSX from 'xlsx';
export default function ExcelPage(){
  const [rows, setRows] = useState([]);
  function handle(e){
    const f = e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const data = new Uint8Array(ev.target.result);
      const wb = XLSX.read(data, {type:'array'});
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(sheet, {header:1});
      setRows(json);
    };
    reader.readAsArrayBuffer(f);
  }
  return (
    <div className="container">
      <h2>Excel Preview (SheetJS)</h2>
      <div className="card">
        <input type="file" accept=".xlsx,.xls,.csv" onChange={handle} />
        <div style={{marginTop:12}}>
          <table border="1" cellPadding="6">
            <tbody>
              {rows.map((r, i)=>(
                <tr key={i}>{r.map((c,j)=><td key={j}>{String(c||'')}</td>)}</tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
