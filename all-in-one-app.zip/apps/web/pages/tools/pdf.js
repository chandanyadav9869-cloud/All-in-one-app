import { useState } from 'react';
import axios from 'axios';
export default function PdfPage(){
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('');
  const upload = async () => {
    if (!file) return alert('Choose PDF');
    const fd = new FormData();
    fd.append('pdf', file);
    setStatus('Uploading...');
    try {
      const res = await axios.post((process.env.NEXT_PUBLIC_API_URL||'http://localhost:4000') + '/convert/pdf-to-docx', fd);
      setStatus(JSON.stringify(res.data));
    } catch (e) {
      setStatus('Error: ' + (e.message || e));
    }
  }
  return (
    <div className="container">
      <h2>PDF → Word (Demo)</h2>
      <div className="card">
        <input type="file" accept="application/pdf" onChange={e=>setFile(e.target.files[0])} />
        <div style={{marginTop:12}}>
          <button className="btn" onClick={upload}>Upload & Convert (stub)</button>
        </div>
        <pre style={{marginTop:12}}>{status}</pre>
      </div>
    </div>
  )
}
